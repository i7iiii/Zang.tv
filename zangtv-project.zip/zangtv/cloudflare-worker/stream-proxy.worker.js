// =========================================================
//  ZangTV — Cloudflare Worker
//  Stream Proxy بۆ چارەسەری CORS
//
//  دامەزراندن:
//  1. https://dash.cloudflare.com بچۆ
//  2. Workers & Pages → Create Worker
//  3. ئەم کۆدە paste بکە
//  4. ئەو domain ئەوە لە ALLOWED_ORIGINS زیاد بکە
// =========================================================

const ALLOWED_ORIGINS = [
  "https://zangtv.com",
  "https://www.zangtv.com",
  "http://localhost:3000",   // Development
];

// کەناڵانەی دەتوانن proxy بکرێن — بۆ ئاسایش
const ALLOWED_STREAM_HOSTS = [
  // زیاد بکە domain ی کەناڵەکانی باوەڕپێکراوت
  "kurdsat.tv",
  "rudaw.net",
  "nrttv.com",
  "ktvkurdistan.com",
  "galistream.com",
  // ...
];

// ─────────────────────────────────────────
// Main Handler
// ─────────────────────────────────────────
export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    // Health check
    if (url.pathname === "/health") {
      return new Response(JSON.stringify({ status: "ok", service: "ZangTV Stream Proxy" }), {
        headers: { "Content-Type": "application/json" },
      });
    }

    // OPTIONS preflight
    if (request.method === "OPTIONS") {
      return handleOptions(request);
    }

    // Route: /proxy/stream?url=...
    if (url.pathname === "/proxy/stream") {
      return handleStreamProxy(request, url, env);
    }

    // Route: /proxy/m3u8?url=...
    if (url.pathname === "/proxy/m3u8") {
      return handleM3U8Proxy(request, url, env);
    }

    return new Response("Not Found", { status: 404 });
  },
};

// ─────────────────────────────────────────
// Stream Proxy — HLS Segments و M3U8
// ─────────────────────────────────────────
async function handleStreamProxy(request, url, env) {
  const targetUrl = url.searchParams.get("url");

  if (!targetUrl) {
    return errorResponse("url parameter required", 400);
  }

  // ── Security: بەرپرسایەتی host ──────────────────────
  let targetHost;
  try {
    targetHost = new URL(targetUrl).hostname;
  } catch {
    return errorResponse("Invalid stream URL", 400);
  }

  const isAllowed = ALLOWED_STREAM_HOSTS.some(
    (h) => targetHost === h || targetHost.endsWith("." + h)
  );

  // لە development بگەڕێنە پاشەوە، لە production uncomment بکە:
  // if (!isAllowed) return errorResponse("Stream host not allowed", 403);

  // ── Fetch stream ────────────────────────────────────
  const proxyRequest = new Request(targetUrl, {
    method: request.method,
    headers: {
      "User-Agent": "Mozilla/5.0 (compatible; ZangTV/1.0)",
      "Accept": "*/*",
      "Accept-Language": "ku,ar,en",
      ...(request.headers.get("Range") && { Range: request.headers.get("Range") }),
    },
  });

  let response;
  try {
    response = await fetch(proxyRequest);
  } catch (err) {
    return errorResponse("Failed to fetch stream: " + err.message, 502);
  }

  // ── Response headers ─────────────────────────────────
  const corsHeaders = getCORSHeaders(request);
  const responseHeaders = new Headers(corsHeaders);

  // Content type
  const contentType = response.headers.get("Content-Type") || "application/octet-stream";
  responseHeaders.set("Content-Type", contentType);

  // Content-Range بۆ partial content
  if (response.headers.has("Content-Range")) {
    responseHeaders.set("Content-Range", response.headers.get("Content-Range"));
  }
  if (response.headers.has("Content-Length")) {
    responseHeaders.set("Content-Length", response.headers.get("Content-Length"));
  }

  // Cache بۆ HLS segments
  if (contentType.includes("video") || url.pathname.endsWith(".ts")) {
    responseHeaders.set("Cache-Control", "public, max-age=6");
  } else {
    responseHeaders.set("Cache-Control", "no-cache");
  }

  return new Response(response.body, {
    status: response.status,
    headers: responseHeaders,
  });
}

// ─────────────────────────────────────────
// M3U8 Proxy — Playlist Rewriting
// لینکە ناوخۆییەکانی m3u8 دەگۆڕێتەوە بۆ proxy
// ─────────────────────────────────────────
async function handleM3U8Proxy(request, url, env) {
  const targetUrl = url.searchParams.get("url");
  if (!targetUrl) return errorResponse("url parameter required", 400);

  let response;
  try {
    response = await fetch(targetUrl, {
      headers: { "User-Agent": "Mozilla/5.0 (compatible; ZangTV/1.0)" },
    });
  } catch (err) {
    return errorResponse("Failed to fetch playlist", 502);
  }

  let m3u8Text = await response.text();
  const baseUrl = new URL(targetUrl);

  // ── Rewrite relative URLs ──────────────────────────
  const proxyBase = url.origin + "/proxy/stream?url=";
  const proxyM3U8 = url.origin + "/proxy/m3u8?url=";

  m3u8Text = m3u8Text
    .split("\n")
    .map((line) => {
      const trimmed = line.trim();
      if (trimmed.startsWith("#")) return line; // M3U8 comment

      if (trimmed.endsWith(".m3u8") || trimmed.includes(".m3u8?")) {
        // Sub-playlist — route through m3u8 proxy
        const absoluteUrl = toAbsoluteUrl(trimmed, baseUrl);
        return proxyM3U8 + encodeURIComponent(absoluteUrl);
      }

      if (trimmed.endsWith(".ts") || trimmed.includes(".ts?") || trimmed.length > 0) {
        // TS segment — route through stream proxy
        const absoluteUrl = toAbsoluteUrl(trimmed, baseUrl);
        return proxyBase + encodeURIComponent(absoluteUrl);
      }

      return line;
    })
    .join("\n");

  const corsHeaders = getCORSHeaders(request);
  return new Response(m3u8Text, {
    status: 200,
    headers: {
      ...corsHeaders,
      "Content-Type": "application/vnd.apple.mpegurl",
      "Cache-Control": "no-cache",
    },
  });
}

// ─────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────
function toAbsoluteUrl(url, base) {
  if (url.startsWith("http://") || url.startsWith("https://")) return url;
  if (url.startsWith("/")) return base.origin + url;
  return base.origin + base.pathname.replace(/\/[^/]*$/, "/") + url;
}

function getCORSHeaders(request) {
  const origin = request.headers.get("Origin") || "*";
  const allowedOrigin = ALLOWED_ORIGINS.includes(origin) ? origin : ALLOWED_ORIGINS[0];

  return {
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Range, Origin, Accept, Content-Type",
    "Access-Control-Expose-Headers": "Content-Length, Content-Range",
    "Access-Control-Max-Age": "86400",
  };
}

function handleOptions(request) {
  return new Response(null, {
    status: 204,
    headers: getCORSHeaders(request),
  });
}

function errorResponse(message, status = 500) {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
    },
  });
}
