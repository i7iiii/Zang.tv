-- =========================================================
--  ZangTV — Database Schema
--  ئەمە خۆکارانە کاردەکات کاتێک postgres دەستپێدەکات
-- =========================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm"; -- بۆ گەڕانی خێرا

-- ─────────────────────────────────────────
-- ENUM Types
-- ─────────────────────────────────────────
CREATE TYPE user_role   AS ENUM ('user', 'moderator', 'admin');
CREATE TYPE user_plan   AS ENUM ('free', 'premium');
CREATE TYPE auth_provider AS ENUM ('local', 'google', 'facebook');
CREATE TYPE channel_status AS ENUM ('active', 'inactive', 'testing');

-- ─────────────────────────────────────────
-- CATEGORIES
-- ─────────────────────────────────────────
CREATE TABLE categories (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slug       VARCHAR(50) UNIQUE NOT NULL,
  name_ku    VARCHAR(100) NOT NULL,
  name_ar    VARCHAR(100) NOT NULL,
  name_en    VARCHAR(100) NOT NULL,
  icon       VARCHAR(50),
  color      VARCHAR(7),    -- hex color
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────
-- USERS
-- ─────────────────────────────────────────
CREATE TABLE users (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name            VARCHAR(100) NOT NULL,
  email           VARCHAR(255) UNIQUE NOT NULL,
  password_hash   VARCHAR(255),                  -- null بۆ OAuth users
  provider        auth_provider DEFAULT 'local',
  provider_id     VARCHAR(255),
  avatar_url      VARCHAR(500),
  role            user_role DEFAULT 'user',
  plan            user_plan DEFAULT 'free',
  plan_expires_at TIMESTAMPTZ,
  is_verified     BOOLEAN DEFAULT FALSE,
  is_banned       BOOLEAN DEFAULT FALSE,
  lang_pref       VARCHAR(5) DEFAULT 'ku',       -- ku, ar, en
  last_login_at   TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_users_email    ON users(email);
CREATE INDEX idx_users_provider ON users(provider, provider_id);

-- ─────────────────────────────────────────
-- CHANNELS
-- ─────────────────────────────────────────
CREATE TABLE channels (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slug        VARCHAR(100) UNIQUE NOT NULL,
  name_ku     VARCHAR(150) NOT NULL,
  name_ar     VARCHAR(150),
  name_en     VARCHAR(150),
  logo_url    VARCHAR(500),
  banner_url  VARCHAR(500),
  stream_url  TEXT NOT NULL,               -- m3u8 لینک
  backup_url  TEXT,                        -- backup stream
  website_url VARCHAR(500),
  category_id UUID REFERENCES categories(id) ON DELETE SET NULL,
  country     VARCHAR(2),                  -- ISO 3166-1 alpha-2
  language    VARCHAR(5),                  -- ku, ar, en, tr
  quality     VARCHAR(10) DEFAULT 'HD',    -- SD, HD, FHD, 4K
  status      channel_status DEFAULT 'active',
  is_featured BOOLEAN DEFAULT FALSE,
  sort_order  INTEGER DEFAULT 0,
  tags        TEXT[],
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_channels_category ON channels(category_id);
CREATE INDEX idx_channels_status   ON channels(status);
CREATE INDEX idx_channels_country  ON channels(country);
CREATE INDEX idx_channels_search   ON channels USING GIN(to_tsvector('simple', name_ku || ' ' || COALESCE(name_en,'') || ' ' || COALESCE(name_ar,'')));

-- ─────────────────────────────────────────
-- FAVORITES
-- ─────────────────────────────────────────
CREATE TABLE favorites (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  channel_id UUID NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, channel_id)
);

CREATE INDEX idx_favorites_user ON favorites(user_id);

-- ─────────────────────────────────────────
-- WATCH SESSIONS — مێژووی بینین + ئامار
-- ─────────────────────────────────────────
CREATE TABLE watch_sessions (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id      UUID REFERENCES users(id) ON DELETE SET NULL,
  channel_id   UUID NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  ip_hash      VARCHAR(64),              -- hashed IP بۆ privacy
  user_agent   VARCHAR(500),
  duration_sec INTEGER DEFAULT 0,
  started_at   TIMESTAMPTZ DEFAULT NOW(),
  ended_at     TIMESTAMPTZ
);

CREATE INDEX idx_watch_user    ON watch_sessions(user_id);
CREATE INDEX idx_watch_channel ON watch_sessions(channel_id);
CREATE INDEX idx_watch_date    ON watch_sessions(started_at DESC);

-- ─────────────────────────────────────────
-- USER PREFERENCES — بۆ AI Recommendation
-- ─────────────────────────────────────────
CREATE TABLE user_preferences (
  user_id          UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  category_weights JSONB DEFAULT '{}',   -- {"sports": 0.8, "news": 0.3}
  country_pref     VARCHAR(2)[],
  lang_pref        VARCHAR(5)[],
  updated_at       TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────
-- REFRESH TOKENS
-- ─────────────────────────────────────────
CREATE TABLE refresh_tokens (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash VARCHAR(255) NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  is_revoked BOOLEAN DEFAULT FALSE
);

CREATE INDEX idx_refresh_user ON refresh_tokens(user_id);

-- ─────────────────────────────────────────
-- SEED DATA — داتای سەرەتایی
-- ─────────────────────────────────────────
INSERT INTO categories (slug, name_ku, name_ar, name_en, icon, color, sort_order) VALUES
  ('kurdish',   'کوردی',      'الكردية',  'Kurdish',     'flag',          '#FF6B35', 1),
  ('news',      'هەواڵ',      'الأخبار',  'News',         'newspaper',     '#2196F3', 2),
  ('sports',    'وەرزش',     'الرياضة',  'Sports',       'ball-football', '#4CAF50', 3),
  ('children',  'منداڵان',    'أطفال',    'Children',     'mood-kid',      '#FF9800', 4),
  ('religious', 'دینی',       'ديني',     'Religious',    'star',          '#9C27B0', 5),
  ('movies',    'فیلم',       'أفلام',    'Movies',       'movie',         '#F44336', 6),
  ('arabic',    'عەرەبی',     'عربية',    'Arabic',       'globe',         '#00BCD4', 7),
  ('music',     'موزیک',      'موسيقى',  'Music',        'music',         '#E91E63', 8);

-- Admin user (password: Admin@123 — دەبێت بگۆڕیت)
INSERT INTO users (name, email, password_hash, role, is_verified) VALUES
  ('Admin', 'admin@zangtv.com', '$2b$12$placeholder_change_this_hash', 'admin', TRUE);
