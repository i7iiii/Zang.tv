#!/usr/bin/env bash
# =========================================================
#  ZangTV — Quick Start Script
#  ./scripts/setup.sh
# =========================================================

set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

echo -e "${BLUE}"
echo "  ███████╗ █████╗ ███╗   ██╗ ██████╗    ████████╗██╗   ██╗"
echo "  ╚══███╔╝██╔══██╗████╗  ██║██╔════╝       ██╔══╝██║   ██║"
echo "    ███╔╝ ███████║██╔██╗ ██║██║  ███╗      ██║   ██║   ██║"
echo "   ███╔╝  ██╔══██║██║╚██╗██║██║   ██║      ██║   ╚██╗ ██╔╝"
echo "  ███████╗██║  ██║██║ ╚████║╚██████╔╝      ██║    ╚████╔╝ "
echo "  ╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝       ╚═╝     ╚═══╝  "
echo -e "${NC}"
echo -e "  ${YELLOW}Kurdish TV Streaming Platform — Setup${NC}"
echo ""

# Check dependencies
echo -e "${BLUE}[1/5]${NC} Checking dependencies..."
command -v docker >/dev/null 2>&1   || { echo -e "${RED}✗ Docker not found. Install: https://docker.com${NC}"; exit 1; }
command -v docker-compose >/dev/null 2>&1 || command -v docker compose >/dev/null 2>&1 || { echo -e "${RED}✗ Docker Compose not found${NC}"; exit 1; }
command -v node >/dev/null 2>&1     || { echo -e "${YELLOW}⚠ Node.js not found (needed for local dev)${NC}"; }
echo -e "${GREEN}✓ Dependencies OK${NC}"

# Copy .env
echo -e "${BLUE}[2/5]${NC} Setting up environment..."
if [ ! -f .env ]; then
  cp .env.example .env
  echo -e "${GREEN}✓ .env created from .env.example${NC}"
  echo -e "${YELLOW}  ⚠ Edit .env with your real values before production!${NC}"
else
  echo -e "${GREEN}✓ .env already exists${NC}"
fi

# Create stub Dockerfiles if not exist
echo -e "${BLUE}[3/5]${NC} Creating stub Dockerfiles..."
mkdir -p backend frontend

if [ ! -f backend/Dockerfile.dev ]; then
cat > backend/Dockerfile.dev << 'DOCKERFILE'
FROM node:20-alpine
WORKDIR /app
RUN npm install -g @nestjs/cli
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 3001
CMD ["npm", "run", "start:dev"]
DOCKERFILE
echo -e "${GREEN}✓ backend/Dockerfile.dev created${NC}"
fi

if [ ! -f frontend/Dockerfile.dev ]; then
cat > frontend/Dockerfile.dev << 'DOCKERFILE'
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 3000
CMD ["npm", "run", "dev"]
DOCKERFILE
echo -e "${GREEN}✓ frontend/Dockerfile.dev created${NC}"
fi

# Minimal package.json stubs
if [ ! -f backend/package.json ]; then
echo '{"name":"zangtv-api","version":"1.0.0","scripts":{"start:dev":"echo NestJS API placeholder"}}' > backend/package.json
fi
if [ ! -f frontend/package.json ]; then
echo '{"name":"zangtv-frontend","version":"1.0.0","scripts":{"dev":"echo Next.js placeholder"}}' > frontend/package.json
fi

# Start core services only (postgres + redis)
echo -e "${BLUE}[4/5]${NC} Starting database and cache..."
docker compose up -d postgres redis

echo -e "${BLUE}[5/5]${NC} Waiting for services to be healthy..."
sleep 5

# Check health
PG_HEALTH=$(docker inspect --format='{{.State.Health.Status}}' zangtv-db 2>/dev/null || echo "unknown")
REDIS_HEALTH=$(docker inspect --format='{{.State.Health.Status}}' zangtv-redis 2>/dev/null || echo "unknown")

echo ""
echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "  ${GREEN}ZangTV Services Status${NC}"
echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "  PostgreSQL  → ${GREEN}localhost:5432${NC}  [${PG_HEALTH}]"
echo -e "  Redis       → ${GREEN}localhost:6379${NC}  [${REDIS_HEALTH}]"
echo ""
echo -e "  ${YELLOW}Next steps:${NC}"
echo -e "  1. Start all services:  ${BLUE}docker compose up -d${NC}"
echo -e "  2. View logs:           ${BLUE}docker compose logs -f${NC}"
echo -e "  3. Open pgAdmin:        ${BLUE}docker compose --profile tools up -d pgadmin${NC}"
echo -e "     → http://localhost:5050"
echo -e "  4. Deploy Worker:       ${BLUE}cd cloudflare-worker && wrangler deploy${NC}"
echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
